/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MathOperation;

/**
 *
 * @author 2ndyrGroupB
 */
public class Multiplication {

    public double product(double a, double b) {
        return a * b;

    }

}
